
import turtle
import random
import winsound

for i in range(2):
    ankit1 = turtle.Turtle()
    ankit1.color("red")
    ankit1.hideturtle()
    
ankit1.penup()
ankit1.goto(-350,280)
ankit1.write("start.Level-4\nYour target:1000",font=("Algerian",15,"normal"),align="left")

def btnclick(x,y):
    ankit = turtle.Screen()
    ankit.title("METEORITE ATTACK")
    ankit.bgcolor("green")
    ankit.bgpic("main3.gif")
    ankit.setup(width=800, height=600) 
    ankit.tracer(0)
    

    score = 0
    life = 5

    ankit.register_shape("spaceship4.gif")
    ankit.register_shape("spaceship4.gif")
    ankit.register_shape("meteor_big2.gif")
    ankit.register_shape("s_med1.gif")
    ankit.register_shape("meteorBrown_big1.gif")
    ankit.register_shape("bolt_gold.gif")
    ankit.register_shape("boom.gif")

    # add the player
    player = turtle.Turtle()
    player.speed(0)
    player.shape("spaceship4.gif")
    player.color("white")
    player.penup()
    player.goto(0,-250)
    player.direction = "stop"

    #list of good guy
    good_guys = []

    # add the good_guys
    for _ in range(5):
        good_guy = turtle.Turtle()
        good_guy.speed(0)
        good_guy.shape("bolt_gold.gif")
        good_guy.color("blue")
        good_guy.penup()
        good_guy.goto(-100,250)
        good_guy.speed = random.randint(1,4)
        good_guys.append(good_guy)

    #list of bad guy
    bad_guys = []

    # add the bad_guys
    for _ in range(1):
        bad_guy = turtle.Turtle()
        bad_guy.speed(0)
        bad_guy.shape("meteor_big2.gif")
        bad_guy.color("red")
        bad_guy.penup()
        bad_guy.goto(100,250)
        bad_guy.speed = random.randint(1,4)
        bad_guys.append(bad_guy)

    #list of bad guy
    bad_guys1 = []

    # add the bad_guys
    for _ in range(1):
        bad_guy1 = turtle.Turtle()
        bad_guy1.speed(0)
        bad_guy1.shape("meteorBrown_big1.gif")
        bad_guy1.color("red")
        bad_guy1.penup()
        bad_guy1.goto(100,250)
        bad_guy1.speed = random.randint(1,4)
        bad_guys1.append(bad_guy1)

    #list of bad guy
    bad_guys2 = []

    # add the bad_guys
    for _ in range(1):
        bad_guy2 = turtle.Turtle()
        bad_guy2.speed(0)
        bad_guy2.shape("s_med1.gif")
        bad_guy2.color("red")
        bad_guy2.penup()
        bad_guy2.goto(100,250)
        bad_guy2.speed = random.randint(1,4)
        bad_guys2.append(bad_guy2)

    # make the pan
    pan = turtle.Turtle()
    pan.hideturtle()
    pan.speed(0)
    pan.shape("square")
    pan.color("white")
    pan.penup()
    pan.goto(0,250)
    font = ("courier",24,"normal")
    pan.write("score:{} life:{}".format(score,life), align="center",font=font)

    # functions
    def go_left():
        player.direction = "left"
        player.shape("spaceship4.gif")

    def go_right():
        player.direction = "right"
        player.shape("spaceship4.gif")

    # keyboard binding
    ankit.listen()
    ankit.onkeypress(go_left,"Left")
    ankit.onkeypress(go_right,"Right")

    # main game loop
    while True:
        # update screen
        ankit.update()

        # move to player
        if player.direction == "left":
            x = player.xcor()
            x -= 1
            player.setx(x)
            if x < -400:
                player.goto(400,-250)


        if player.direction == "right":
            x = player.xcor()
            x += 1
            player.setx(x)
            if x > 400:
                player.goto(-400,-250)

        #good_guys moving
        for good_guy in good_guys:
            y  = good_guy.ycor()
            y -= good_guy.speed
            good_guy.sety(y)

            #chek if off the screen
            if y < -300:
                x = random.randint(-300,300)
                y = random.randint(300,400)
                good_guy.goto(x,y)
            
            # chek for the colision with the player
            if good_guy.distance(player) < 50:
                winsound.PlaySound("mario_power_up.mp3",winsound.SND_ASYNC)
                x = random.randint(-300,300)
                y = random.randint(300,400)
                good_guy.goto(x,y)
                score += 10
                pan.clear()
                pan.write("score:{} life:{}".format(score,life), align="center",font=font)
                if score >= 1000:
                    pan.clear()
                    player.goto(x,y)
                    bad_guy.goto(x,y)
                    bad_guy1.goto(x,y)
                    bad_guy2.goto(x,y)
                    good_guy.goto(x,y)
                    for i in range(2):
                        ankit = turtle.Turtle()
                        ankit.color("yellow")
                        ankit.hideturtle()
                        
                    ankit.penup()
                    ankit.goto(-50,0)
                    ankit.write("LEVEL COMPLETE\nYOUR score:{}".format(score),font=("Algerian",15,"normal"),align="left")
                    ankit.mainloop()

           
     #bad_guys moving
        for bad_guy in bad_guys:
            y  = bad_guy.ycor()
            y -= bad_guy.speed
            bad_guy.sety(y)

            #chek if off the screen
            if y < -300:
                x = random.randint(-300,300)
                y = random.randint(300,400)
                bad_guy.goto(x,y)
            
            # chek for the colision with the player
            if bad_guy.distance(player) < 50:
                player.shape("boom.gif")
                x = random.randint(-300,300)
                y = random.randint(300,400)
                bad_guy.goto(x,y)
                score -= 10
                life -= 1
                pan.clear()
                pan.write("score:{} life:{}".format(score,life), align="center",font=font)
                if life <= 0:
                    pan.clear()
                    player.goto(x,y)
                    bad_guy.goto(x,y)
                    bad_guy1.goto(x,y)
                    bad_guy2.goto(x,y)
                    good_guy.goto(x,y)
                    for i in range(2):
                        ankit = turtle.Turtle()
                        ankit.color("red")
                        ankit.hideturtle()
                        
                    ankit.penup()
                    ankit.goto(-50,0)
                    ankit.write("GAME OVER\nYOUR score:{}".format(score),font=("Algerian",15,"normal"),align="left")
                    ankit.mainloop()

     #bad_guys1 moving
        for bad_guy1 in bad_guys1:
            y  = bad_guy1.ycor()
            y -= bad_guy1.speed
            bad_guy1.sety(y)

            #chek if off the screen
            if y < -300:
                x = random.randint(-300,300)
                y = random.randint(300,400)
                bad_guy1.goto(x,y)
            
            # chek for the colision with the player
            if bad_guy1.distance(player) < 50:
                player.shape("boom.gif")
                x = random.randint(-300,300)
                y = random.randint(300,400)
                bad_guy1.goto(x,y)
                score -= 10
                life -= 1
                pan.clear()
                pan.write("score:{} life:{}".format(score,life), align="center",font=font)
                if life <= 0:
                    pan.clear()
                    player.goto(x,y)
                    bad_guy.goto(x,y)
                    bad_guy1.goto(x,y)
                    bad_guy2.goto(x,y)
                    good_guy.goto(x,y)
                    for i in range(2):
                        ankit = turtle.Turtle()
                        ankit.color("red")
                        ankit.hideturtle()
                        
                    ankit.penup()
                    ankit.goto(-50,0)
                    ankit.write("GAME OVER\nYOUR score:{}".format(score),font=("Algerian",15,"normal"),align="left")
                    ankit.mainloop()


     #bad_guys2 moving
        for bad_guy2 in bad_guys2:
            y  = bad_guy2.ycor()
            y -= bad_guy2.speed
            bad_guy2.sety(y)

            #chek if off the screen
            if y < -300:
                x = random.randint(-300,300)
                y = random.randint(300,400)
                bad_guy2.goto(x,y)
            
            # chek for the colision with the player
            if bad_guy2.distance(player) < 50:
                player.shape("boom.gif")
                x = random.randint(-300,300)
                y = random.randint(300,400)
                bad_guy2.goto(x,y)
                score -= 10
                life -= 1
                pan.clear()
                pan.write("score:{} life:{}".format(score,life), align="center",font=font)
                if life <= 0:
                    pan.clear()
                    player.goto(x,y)
                    bad_guy2.goto(x,y)
                    bad_guy1.goto(x,y)
                    bad_guy.goto(x,y)
                    good_guy.goto(x,y)
                    for i in range(2):
                        ankit = turtle.Turtle()
                        ankit.color("red")
                        ankit.hideturtle()
                        
                    ankit.penup()
                    ankit.goto(-50,0)
                    ankit.write("GAME OVER\nYOUR score:{}".format(score),font=("Algerian",15,"normal"),align="left")
                    ankit.mainloop()
                
    delay = input ("press the enter to finish")
    ankit.mainloop()
    
 
 
turtle.onscreenclick(btnclick, 1)
turtle.listen()

ankit1.mainloop()
