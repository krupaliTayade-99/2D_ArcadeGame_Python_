import turtle
import random
import winsound

for i in range(2):
    ankit1 = turtle.Turtle()
    ankit1.color("red")
    ankit1.hideturtle()
    
ankit1.penup()
ankit1.goto(-140,280)
ankit1.write("WELCOME TO 'METEORITE ATTACK' GAME\n"
             ,font=("Algerian",15,"normal"),align="left")
for i in range(2):
    ankit1 = turtle.Turtle()
    ankit1.color("blue")
    ankit1.hideturtle()
    
ankit1.penup()
ankit1.goto(-140,180)
ankit1.write("\n         Game Controls:\n"
             "\nFor Left Move = Left Press Left ->\n"
             "For Right Move = Right Press Left <-\n"
             ,font=("Algerian",15,"normal"),align="left")
for i in range(2):
    ankit1 = turtle.Turtle()
    ankit1.color("blue")
    ankit1.hideturtle()
    
ankit1.penup()
ankit1.goto(-330,-140)
ankit1.write("\n"
             "                                               Game tips:\n"
             "\nIf you manage to catch first coming power(Lightnening Bolt)"
             "\nthen you have a goldenchance to gain 50 points at a time, after"
             "\nthat for every poweryou will be rewarded with 10 point If in"
             "\nbetween you  collide with meteorite you will be losing10 points"
             "\nfor each collision.Level by level the game will get even more"
             "\ntough to win.Speed of meteorite increases and the collision"
             "\ndistance between spaceship and meteorite is decreased so as to"
             "\nmake it more difficult,but then you have one positve side, you"
             "\ncan dodge meteorite easily but you will be dodging your power too.\n"
             ,font=("Algerian",15,"normal"),align="left")
for i in range(2):
    ankit1 = turtle.Turtle()
    ankit1.color("red")
    ankit1.hideturtle()
    
ankit1.penup()
ankit1.goto(-90,-180)
ankit1.write("THANK YOU For Playing, Enjoy!"
             ,font=("Algerian",15,"normal"),align="left")
